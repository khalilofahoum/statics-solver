Statics Solver - setup
======================

1. Extract this zip (right-click > Extract All).
2. Double-click install.bat.

install.bat copies the program to %LOCALAPPDATA%\StaticsSolver, downloads the
formula fonts (KaTeX 0.16.9 from cdn.jsdelivr.net, about 600 KB) and creates a
"Statics Solver" icon on the Desktop. It needs no administrator rights.

The program runs in your web browser and works offline after the setup.
If the download fails, the program still works and formulas appear as plain
text; run install.bat again when you are online.

To remove it: delete %LOCALAPPDATA%\StaticsSolver and the Desktop icon.
